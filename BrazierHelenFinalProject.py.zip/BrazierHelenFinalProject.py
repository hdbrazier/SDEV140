"""

Author: Helen Brazier
Date Written: 03/06/25
Program: Final Project - Flight Aid
Assignment: SDEV140 Final project source code
Description: GUI program simulating a dispatchers workload when taking a call to transfer a patient and loggin patient details

"""
import tkinter as tk
from tkinter import messagebox, Text
from tkinter import ttk
import PIL
from PIL import Image, ImageTk  

# Function for validating entries 
def validateInput(inputText):
    """Checks entries are valid and integers"""
    if not inputText:
        return False, "Input cannot be empty." # message displayed if there is missing input
    try:
        int(inputText)
        return True, "" # no message is displayed if inputs are valid
    except ValueError:
        return False, "Input must be a valid number." # message is displayed if exception is raised

# Callback function for the "Initiate Transfer" button
def initiateTransfer():
    """Retrieves input for employee number and time of call, displays confirmation window"""
    inputText1 = employeeNumberInput.get()
    inputText2 = timeOfCallInput.get()
    
    isValid1, message1 = validateInput(inputText1)
    isValid2, message2 = validateInput(inputText2)
    # confirm validation both inputs are entered or displays an error
    if isValid1 and isValid2:
        messagebox.showinfo("Transfer Initiated", "A transfer request has been started.") 
    else:
        messagebox.showerror("Input Error", f"{message1}\n{message2}")

# Callback function for opening the second window
def transportDetails():
    secondWindow = tk.Tk() # create window
    secondWindow.title("Transport and Patient Details") # title window
    secondWindow.geometry("400x750") # size window
    
    # Label in the second window
    message = tk.Label(secondWindow, text="Patient Details", font=("Arial", 18)) # insert label
    message.pack(pady=20) # set label position
    
    # First Dropdown Menu (options to choose) 
    sendingLbl = tk.Label(secondWindow, text="Choose Sending Facility:") # label for dropdown
    sendingLbl.pack(pady=10) # set label position
    # create dropdown list of options and set position 
    sendingList = ttk.Combobox(secondWindow, values=["Marion General", "Kokomo St.V", "Anderson St.V", "IU Tipton", "Rush Memorial"])
    sendingList.pack(pady=5)

    # Second Dropdown Menu (options to choose)
    receivingLbl = tk.Label(secondWindow, text="Choose Receiving Facility:") # label for dropdown
    receivingLbl.pack(pady=10) # set label position 
    # create dropdown list of options and set position
    receivingList = ttk.Combobox(secondWindow, values=["86th St", "Methodist", "Heart Center", "Ezkenazi", "Riley"])
    receivingList.pack(pady=5)

    # Label and Input Field for patient name
    patientNameLbl = tk.Label(secondWindow, text="Patient Name:") # create patient name label
    patientNameLbl.pack(pady=10) # set position
    patientNameInput = tk.Entry(secondWindow) # create entry box for user input
    patientNameInput.pack(pady=5) # set position
    
    # Label and Input Field for patient weight
    patientWeightLbl = tk.Label(secondWindow, text="Patient Weight:") # create patient weight label
    patientWeightLbl.pack(pady=10) # set position
    patientWeightInput = tk.Entry(secondWindow) # create entry box for user input
    patientWeightInput.pack(pady=5) # set position

    # Label and Input Field for patient age 
    patientAgeLbl = tk.Label(secondWindow, text="Patient Age:") # create patient age label
    patientAgeLbl.pack(pady=10) # set position
    patientAgeInput = tk.Entry(secondWindow) # create entry box for user input 
    patientAgeInput.pack(pady=5) # set position

    # Third Dropdown Menu (options to choose)
    reasonLbl = tk.Label(secondWindow, text="Choose Reason for Transfer:") # create dropdown for reason of transfer
    reasonLbl.pack(pady=10) # set position 
    # create list of options to choose from and set position
    reasonList = ttk.Combobox(secondWindow, values=["Stroke", "Neuro", "Heart Attack", "AAA", "OB", "Burn", "MVA"])
    reasonList.pack(pady=5)

    # Button to Submit the form data
    btnSubmit = tk.Button(secondWindow, text="Submit", command=lambda: submitFormData(sendingList, receivingList, patientNameInput, patientWeightInput, patientAgeInput, reasonList), font=("Arial", 12))
    btnSubmit.pack(pady=10)

    # Button to Save info to file
    btnSaveToFile = tk.Button(secondWindow, text="Save to file", command=lambda: saveToFile(employeeNumberInput, timeOfCallInput, sendingList, receivingList, patientNameInput, patientWeightInput, patientAgeInput, reasonList), font=("Arial", 12))
    btnSaveToFile.pack(pady=20)  
    
    # Button to Close the second window
    btnClose = tk.Button(secondWindow, text="Close", command=secondWindow.destroy)
    btnClose.pack(pady=10)

# Function to handle form submission in the second window
def submitFormData(sendingList, receivingList, patientNameInput, patientWeightInput, patientAgeInput, reasonList):
    """Retrieves user input and checks for errors on the form"""
    sending = sendingList.get()
    receiving = receivingList.get()
    patientName = patientNameInput.get()
    patientWeight = patientWeightInput.get()
    patientAge = patientAgeInput.get()
    reason = reasonList.get()

    # check if all dropdown and inputs are selected or filled in, displays a message if correct or not
    if not sending or not receiving or not patientName or not patientWeight or not patientAge or not reason:
        messagebox.showerror("Form Error", "All fields must be filled out.")
    elif patientName.isalpha() == False: # display an error message if name includes non-alpha characters
        messagebox.showerror("Form Error", "Patient name should contain only alphabetic characters")
    elif patientWeight.isnumeric() == False: # displays an error message if weight includes non-numeric characters
        messagebox.showerror("Form Error", "Patient weight should be numeric")
    elif patientAge.isnumeric() == False: # displays an error message if age includes non-numeric characters
        messagebox.showerror("Form Error", "Patient age should be numeric")
    # displays a confirmation window with entered details
    else:
        messagebox.showinfo("Form Submitted", f"Form submitted with:\nSending Hospital: {sending}\nReceiving Hospital: {receiving}\nPatient Name: {patientName}\nPatient Weight: {patientWeight}\nPatient Age: {patientAge}\nReason: {reason}")
    
    
    
def saveToFile(employeeNumberInput, timeOfCallInput, sendingList, receivingList, patientNameInput, patientWeightInput, patientAgeInput, reasonList):
    textFile = open("Transfer Logs.txt", "a+") # will append the set of information to the file for record keeping 
    textFile.write(f"\nEmployee Number: {employeeNumberInput.get()}\nTime of call: {timeOfCallInput.get()}\nSending Hospital: {sendingList.get()}\nReceiving Hospital: {receivingList.get()}\nPatient Name: {patientNameInput.get()}\nPatient Weight: {patientWeightInput.get()}\nPatient Age: {patientAgeInput.get()}\nReason: {reasonList.get()}\n")
    messagebox.showinfo("Success", "Data has been saved to file.")
    textFile.close()
    employeeNumberInput.delete(0, 'end') # reset the entry box to empty so user can take a new call without restarting
    timeOfCallInput.delete(0, 'end') # reset the entry box to empty so user can take a new call without restarting

# Callback function for the "Exit" button
def exitProgram():
    """Ask user to confirm they wish to exit"""
    response = messagebox.askyesno("Exit", "Do you want to exit the application?")
    if response:
        window.quit() # quits the application

# Main window
window = tk.Tk() # create window
window.title("FLIGHT AID - Air Medical Transport") # title window
window.geometry("700x450") # size window

# Label in the main window and set position 
greeting = tk.Label(window, text="Transport Details", font=("Arial", 16))
greeting.pack(pady=30)

# Load and display image 1 in the main window
img1 = Image.open("image1.jpg")  # open image
img1 = img1.resize((150, 150), PIL.Image.LANCZOS) # size image
img1 = ImageTk.PhotoImage(img1)
imgLbl = tk.Label(window, image=img1) 
imgLbl.image = img1  # keep a reference to prevent garbage collection
imgLbl.place(x=50, y=50)

# Add Alt text (Label below the first image) and set position
altText1 = "Image of an air medical helicopter"
altTextLbl1 = tk.Label(window, text=altText1, font=("Arial", 10), fg="gray") 
altTextLbl1.place(x=55, y=205) 

# Load and display image 2 in the main window
img2 = Image.open("image2.jpg")  # open image
img2 = img2.resize((150, 150), PIL.Image.LANCZOS) # size image
img2 = ImageTk.PhotoImage(img2)
imgLbl2 = tk.Label(window, image=img2)
imgLbl2.image = img2  # keep a reference to prevent garbage collection
imgLbl2.place(x=500, y=50) # set position

# Add Alt text (Label below the second image) and set position
altText2 = "Image of an Emergency room"
altTextLbl2 = tk.Label(window, text=altText2, font=("Arial", 10), fg="gray")
altTextLbl2.place(x=500, y=205)

# Create label and input for employee to record who takes the call 
employeeNumberLbl = tk.Label(window, text="Enter your employee number:") # create label
employeeNumberLbl.pack(pady=10) # set position
employeeNumberInput = tk.Entry(window, font=("Arial", 14)) # create entry box
employeeNumberInput.pack(pady=10) # set position

# Create label and entry box for employee to record when the call comes in
timeOfCallLbl = tk.Label(window, text="Enter the time of call request:") # create label
timeOfCallLbl.pack(pady=10) # set position
timeOfCallInput = tk.Entry(window, font=("Arial", 14)) # create entry box
timeOfCallInput.pack(pady=10) # set position

# Button to initiate transfer, command validates user entries and set position of button
btnInitiateTransfer = tk.Button(window, text="Initiate Transfer", command=initiateTransfer, font=("Arial", 12))
btnInitiateTransfer.pack(pady=10)

# Button to open add patient details, command opens the second window and set position of button
btnAddPatientDetails = tk.Button(window, text="Add Patient Details", command=transportDetails, font=("Arial", 12))
btnAddPatientDetails.pack(pady=10)

# Button to exit the program on command and set position of button 
btnExit = tk.Button(window, text="Exit", command=exitProgram, font=("Arial", 12))
btnExit.pack(pady=10)

# Run the program
window.mainloop()
